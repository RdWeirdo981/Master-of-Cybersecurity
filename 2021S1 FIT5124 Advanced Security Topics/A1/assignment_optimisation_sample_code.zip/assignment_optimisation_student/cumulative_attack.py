import random
import os
import operator
import csv
from itertools import cycle
import numpy as np
from scipy.optimize import linear_sum_assignment

#https://docs.scipy.org/doc/scipy-0.18.1/reference/generated/scipy.optimize.linear_sum_assignment.html

def cumulative_attack(raw_data,ope_data):


    #Step 1: compute the histograms of list_raw_data and ope_data
   
    #Step 2: compute emperical CDFs of raw and ope data
    
    #Step 3_1: Compute the cost matrix C and then use LSAP
  
    #Step 3_2: apply linear_sum_assignment to identify the weight matrix X
   
    #Step 4: export the mapping
    
    return 0

def file_reader (reader, lst,index):

    for i, row in enumerate(reader): #i starts from 0
        if i!=0:
            lst.append(int(row[index]))
  
if __name__ == '__main__':

    #raw dict and enc dict
    raw_age= list()
    enc_age = list()

    #read the plaintext  file
    plaintext_file = open("auxiliary.csv", "r", newline='') #   covid_true dataset.csv
    p_reader = csv.reader(plaintext_file,delimiter=',')
    file_reader(p_reader,raw_age,0)


    #read the cipher  file
    cipher_file = open("ope_enc_covid_age.csv", "r", newline='')
    c_reader = csv.reader(cipher_file,delimiter=',')
    file_reader(c_reader,enc_age,0)


    cumulative_attack(raw_age,enc_age) 


